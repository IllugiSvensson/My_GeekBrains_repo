#include <iostream>
#include <cmath>
#include <boost/cstdint.hpp>
using namespace std;

//Задача 1
class Figure {
public:

    virtual void area() = 0;

};

class Parallelogram : public Figure {
private:

    unsigned int base;
    unsigned int height;

public:

    Parallelogram(unsigned int b = 0, unsigned h = 0): base(b), height(h)  {

    }

    void area() {

        cout << "Area of Parallelogram: " << base * height << endl;

    }

};

class Circle : public Figure {
private:

    unsigned int radius;

public:

    Circle(unsigned int r = 0): radius(r) {

    }

    void area() {

        cout << "Area of Circle: " << M_PI * radius * radius << endl;

    }

};

class Rectangle : public Parallelogram {
private:

    unsigned int lenght;
    unsigned int width;

public:

    Rectangle(unsigned int l = 0, unsigned w = 0): lenght(l), width(w) {

    }

    void area() {

        cout << "Area of Rectangle: " << lenght * width << endl;

    }

};

class Square : public Parallelogram {
private:

    unsigned int side;

public:

    Square(unsigned int s = 0): side(s) {

    }

    void area() {

        cout << "Area of Square: " << pow(side, 2) << endl;

    }

};

class Rhombus : public Parallelogram {
private:

    unsigned int diag1;
    unsigned int diag2;

public:

    Rhombus(unsigned int d1 = 0, unsigned int d2 = 0): diag1(d1), diag2(d2) {

    }

    void area() {

        cout << "Area of Rhombus: " << diag1 * diag2 * 0.5 << endl;

    }

};


int main(int argc, char *argv[]) {

    Parallelogram parallelogram(5, 4);
    Figure *figureP = &parallelogram;

    Circle circle(2);
    Figure *figureC = &circle;

    Rectangle rectangle(2, 3);
    Figure *figureR = &rectangle;

    Square square(7);
    Figure *figureS = &square;

    Rhombus rhombus(1, 5);
    Figure *figureRh = &rhombus;

    figureP -> area();
    figureC -> area();
    figureR -> area();
    figureS -> area();
    figureRh -> area();

return 0;
}
