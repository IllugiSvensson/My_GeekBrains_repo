#include <iostream>
#include <cmath>
#include <boost/cstdint.hpp>
using namespace std;

//Задача 3
//Предусмотреть,
//чтобы знаменатель не был равен 0. Перегрузить математические бинарные операторы (+, -, *, /) для выполнения
//действий с дробями, а также унарный оператор (-). Перегрузить логические операторы сравнения двух
//дробей (==, !=, <, >, <=, >=). Поскольку операторы < и >=, > и <= — это логические противоположности,
//попробуйте перегрузить один через другой.
class Fraction {
public:

    virtual void frac() = 0;

};

class SimpleFraction: public Fraction {
private:

    int numerator;
    int denominator;

public:

    SimpleFraction(int num, int den) {

        numerator = num;
        denominator = den;

    }

    SimpleFraction operator + (int val) {



    }



};

class MixedFraction: public Fraction {
private:

    int numerator;
    int denominator;
    int integerpart;

public:

    MixedFraction(int num, int den, int ipart): numerator(num), denominator(den), integerpart(ipart) {

    }

};

int main(int argc, char *argv[]) {

return 0;
}
